package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

public class doctorSceneController {



    private ObservableList data;

    public Tab patientTab;
    public Tab inspectionTab;

    public TableView patientTable;
    public TableView insDetailTable;

    public TextField pIDText;
    public TextField receiptCodeText;
    public TextArea receiptDescText;

    public String wanted_Column;




    @FXML
    void patientTabSelected(Event event)throws IOException {

        if (patientTab.isSelected()) {
            System.out.println("Tab is Selected");
            fillTable("patients",patientTable);

        }
    }

    @FXML
    void insTabSelected(Event ev) {
        if (inspectionTab.isSelected()) {
            System.out.println("Tab is Selected");

            fillTable("inspections_detail",insDetailTable);
            receiptCodeText.setText(generateReceiptCode());
        }
    }

    public void fillTable(String tableName, TableView table){
        table.getColumns().clear();
        Connection c ;

        data = FXCollections.observableArrayList();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");

            //sql string ifademiz.
            String SQL = "SELECT * from "+tableName+" ";//tablomuzun adı bilgi. id ve adi alanları var.
            //ResultSet
            ResultSet rs = conn.createStatement().executeQuery(SQL);



            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                table.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            //ObservableList e verileri ekleyen döngü
            while(rs.next()){
                //Satırları yinele
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //sütunları yinele
                    row.add(rs.getString(i));
                }
                System.out.println("Satır eklendi "+row );
                data.add(row);
            }

            //Sonucu tabloya ekleme
            table.setItems(data);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hata oluştu");
        }
    }

    public void clearPatientTable (ActionEvent event){
        fillTable("patients",patientTable);
    }

    public void createReceiptDetail(ActionEvent event){


        String receiptCode = receiptCodeText.getText();
        String receiptDesc = receiptDescText.getText();
        int insID = Integer.parseInt(wanted_Column);

        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");
            System.out.println("DB Connected");
            //String query = "Insert into patients(P_Name,P_Surname,B_Date,Gender,Adress,Phone_Number) values('"+pname+"','"+psurname+"','"+pbirthdate+"','"+pgender+"','"+paddress+"','"+pphone+"')";
            String query = "CALL updateInspectionDetail('"+insID+"','"+receiptCode+"','"+receiptDesc+"')";

            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);
            System.out.print("inserted");

            receiptCodeText.setText(generateReceiptCode());

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }


        receiptCodeText.clear();
        receiptDescText.clear();

        fillTable("inspections_detail",insDetailTable);
    }

    public void searchPatient(ActionEvent event){
        patientTable.getColumns().clear();
        String pid = pIDText.getText();


        data = FXCollections.observableArrayList();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");

            //sql string ifademiz.
            //String SQL = "SELECT * from patients where P_ID = '"+pid+"'";//tablomuzun adı bilgi. id ve adi alanları var.
            String SQL = "CALL searchPatient('"+pid+"')";


            //ResultSet
            ResultSet rs = conn.createStatement().executeQuery(SQL);



            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                patientTable.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            //ObservableList e verileri ekleyen döngü
            while(rs.next()){
                //Satırları yinele
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //sütunları yinele
                    row.add(rs.getString(i));
                }
                System.out.println("Satır eklendi "+row );
                data.add(row);
            }

            //Sonucu tabloya ekleme
            patientTable.setItems(data);
            pIDText.setText(null);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hata oluştu");
        }
    }

    public String generateReceiptCode(){
        int generatedCode;
        Random rand = new Random();
        generatedCode = rand.nextInt(9000)+1000;
        String result = "#"+generatedCode;
        return result;
    }

    @FXML
    public void selectFirst(MouseEvent event){
        Object selectedItems = insDetailTable.getSelectionModel().getSelectedItems();
        wanted_Column = selectedItems.toString().split(",")[0].substring(2);
        System.out.println(wanted_Column);
    }


}
