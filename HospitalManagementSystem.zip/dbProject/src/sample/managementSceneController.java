package sample;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Callback;


import javax.swing.plaf.synth.SynthScrollBarUI;
import java.io.IOException;
import java.sql.*;
import java.util.Random;
import java.util.prefs.Preferences;

public class managementSceneController {

    public TabPane tabPane;

    public Button insPatientBtn;
    public Button searchPatientBtn;
    public Button clearPatientBtn;

    //Patient
    public Tab patientTab;
    public TextField pName;
    public TextField pSurname;
    public TextField pBirthDate;
    public TextField pGender;
    public TextArea pAddress;
    public TextField pPhone;
    public TextField pID;
    public TableView tableview;
    private ObservableList data;


    //inspection
    public Tab inspectionTab;
    public TextField receiptCodeText;
    public TextArea receiptDescText;
    public TableView inspectionTable;
    public TableView insDetailTable;
    public TextField patientIDText;
    public TextField pCompText;
    public DatePicker insdate;
    public TextField insClock;
    public TextField docIDText;

    //Doctor
    public Tab doctorTab;
    public TableView doctorTable;
    public TableView doctorAvailabilityTable;

    //add doctor
    public Tab addDoctorTab;
    public TextField docNameText;
    public TextField docSurnameText;
    public DatePicker docdate;
    public TextArea docAddressText;
    public TextField docGenderText;
    public TextField docPhoneText;
    public TextField docExpertiseText;
    public TableView addDoctorTable;

    //Employee
    public Tab employeeTab;
    public TableView employeeTable;
    public TableView employeeInfoTable;

    public TextField empNameText;
    public TextField empSurnameText;
    public TextField empPhoneText;
    public TextField empAddressText;
    public TextField empEmailText;

    //Product
    public Tab productTab;

    public TableView productInfoTable;

    public TextField productNameText;
    public TextField categoryText;

    //Order
    public Tab orderTab;

    public TableView productOrderTable;
    public TableView productStockTable;

    public TextField quantityText;


    public String wanted_quantity;
    public String wanted_product;
    public String wanted_Column;

    public Tab exitTab;

    public void nullRequireInfo(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Error occured");
        alert.setHeaderText(null);
        alert.setContentText("Please enter required information");
        alert.showAndWait();
    }

    public void clearPatientTable (ActionEvent event){
        fillTable("SELECT * FROM patients",tableview);
    }

    public void insertPatient(ActionEvent event){

        String pname = pName.getText();
        String psurname = pSurname.getText();
        String pbirthdate = pBirthDate.getText();
        String pgender = pGender.getText();
        String paddress = pAddress.getText();
        String pphone = pPhone.getText();

        try{

            if(!pName.getText().trim().isEmpty() && !pSurname.getText().trim().isEmpty() && !pBirthDate.getText().trim().isEmpty() && !pGender.getText().trim().isEmpty() && !pAddress.getText().trim().isEmpty() && !pPhone.getText().trim().isEmpty() ){
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");
                System.out.println("DB Connected");
                //String query = "Insert into patients(P_Name,P_Surname,B_Date,Gender,Adress,Phone_Number) values('"+pname+"','"+psurname+"','"+pbirthdate+"','"+pgender+"','"+paddress+"','"+pphone+"')";
                String query = "CALL insertPatient('"+pname+"','"+psurname+"','"+pbirthdate+"','"+pgender+"','"+paddress+"','"+pphone+"')";

                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");

                pName.setText(null);
                pSurname.setText(null);
                pBirthDate.setText(null);
                pGender.setText(null);
                pAddress.setText(null);
                pPhone.setText(null);

            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

            nullRequireInfo();


        }
        fillTable("SELECT * FROM patients",tableview);
    }


    //TODO: create procedure for insert doctor
    public void insertDoctor(ActionEvent event){
        String docname = docNameText.getText();
        String docsurname = docSurnameText.getText();
        String docbirth = docdate.getValue().toString();
        String docgender = docGenderText.getText();
        String docaddress = docAddressText.getText();
        String docphone = docPhoneText.getText();
        String docexpertise = docExpertiseText.getText();


        try{
            if(!docNameText.getText().trim().isEmpty() && !docSurnameText.getText().trim().isEmpty() && docdate.getValue() != null && !docGenderText.getText().trim().isEmpty() && !docAddressText.getText().trim().isEmpty() && !docPhoneText.getText().trim().isEmpty() &&  !docExpertiseText.getText().trim().isEmpty()){

                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");
            System.out.println("DB Connected");
            String query = "Insert into doctors(D_Name,D_Surname,B_Date,Gender,Adress,Phone_Number,Expertise) values('"+docname+"','"+docsurname+"','"+docbirth+"','"+docgender+"','"+docaddress+"','"+docphone+"','"+docexpertise+"')";


            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);
            System.out.print("inserted");

            docNameText.setText(null);
            docSurnameText.setText(null);
            docNameText.setText(null);
            docGenderText.setText(null);
            docAddressText.setText(null);
            docPhoneText.setText(null);
            docExpertiseText.setText(null);
            }else{
                nullRequireInfo();

            }


        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());
        }


        fillTable("SELECT * FROM doctor_without_id",addDoctorTable);

    }

    public void insertEmployeeInformation(ActionEvent event){

        String empName = empNameText.getText();
        String empSurname = empSurnameText.getText();
        String empPhone = empPhoneText.getText();
        String empAddress = empAddressText.getText();
        String empEmail = empEmailText.getText();

        try{
           if(!empNameText.getText().trim().isEmpty() && !empSurnameText.getText().trim().isEmpty() && !empPhoneText.getText().trim().isEmpty() && !empAddressText.getText().trim().isEmpty() && !empEmailText.getText().trim().isEmpty()) {
               Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
               System.out.println("DB Connected");
               String query = "Insert into employee_information(Name,Surname,Phone_Number,Address,Email) values('" + empName + "','" + empSurname + "','" + empPhone + "','" + empAddress + "','" + empEmail + "')";


               Statement stmt = conn.createStatement();
               stmt.executeUpdate(query);
               System.out.print("inserted");

               empNameText.setText(null);
               empSurnameText.setText(null);
               empPhoneText.setText(null);
               empAddressText.setText(null);
               empEmailText.setText(null);
           }else{
               nullRequireInfo();
           }



        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }
        fillTable("SELECT * FROM employee_without_id",employeeTable);

        fillTable("SELECT * FROM employeeinfo_without_id",employeeInfoTable);
    }

    public void searchPatient(ActionEvent event){
        tableview.getColumns().clear();
        String pid = pID.getText();


        data = FXCollections.observableArrayList();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");

            //sql string ifademiz.
            //String SQL = "SELECT * from patients where P_ID = '"+pid+"'";//tablomuzun adı bilgi. id ve adi alanları var.
            String SQL = "CALL searchPatient('"+pid+"')";


            //ResultSet
            ResultSet rs = conn.createStatement().executeQuery(SQL);



            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                tableview.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            //ObservableList e verileri ekleyen döngü
            while(rs.next()){
                //Satırları yinele
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //sütunları yinele
                    row.add(rs.getString(i));
                }
                System.out.println("Satır eklendi "+row );
                data.add(row);
            }

            //Sonucu tabloya ekleme
            tableview.setItems(data);
            pID.setText(null);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hata oluştu");
        }
    }

    public String generateReceiptCode(){
        int generatedCode;
        Random rand = new Random();
        generatedCode = rand.nextInt(9000)+1000;
        String result = "#"+generatedCode;
        return result;
   }


    @FXML
    void patientTabSelected(Event event)throws IOException {

        if (patientTab.isSelected()) {
            System.out.println("Tab is Selected");
            fillTable("SELECT * FROM patients",tableview);

        }
    }

    @FXML
    void insTabSelected(Event ev) {
        if (inspectionTab.isSelected()) {
            System.out.println("Tab is Selected");

            fillTable("SELECT * FROM inspection_without_id",inspectionTable);
            fillTable("SELECT * FROM insdetail_without_id",insDetailTable);
            receiptCodeText.setText(generateReceiptCode());
        }
    }

    @FXML
    void doctorTabSelected(Event ev){
        if(doctorTab.isSelected()){
            System.out.println("Tab is selected");

            fillTable("SELECT * FROM doctor_without_id",doctorTable);
            fillTable("SELECT * FROM doctora_without_id",doctorAvailabilityTable);

        }
    }

    @FXML
    void addDoctorTabSelected(Event ev){
        if(addDoctorTab.isSelected()){
            System.out.println("Tab is selected");
            fillTable("SELECT * FROM doctor_without_id",addDoctorTable);
        }
    }

    @FXML
    void employeeTabSelected(Event ev){
        if(employeeTab.isSelected()){
            System.out.println("Tab is selected");
            fillTable("SELECT * FROM employee_without_id",employeeTable);
            fillTable("SELECT * FROM employeeinfo_without_id",employeeInfoTable);
        }
    }

    @FXML
    void productTabSelected(Event ev){
        if(productTab.isSelected()){
            System.out.println("Tab is selected");
            fillTable("SELECT * FROM product_info",productInfoTable);
        }
    }

    @FXML
    void orderTabSelected(Event ev){
        if(orderTab.isSelected()){
            System.out.println("Tab is selected");
            fillTable("SELECT * FROM product_order",productOrderTable);
            fillTable("SELECT * FROM product_stock",productStockTable);
        }
    }

    @FXML
    void exitButton(ActionEvent ev)throws IOException{
        Parent loginParent = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene loginScene = new Scene(loginParent);

        Stage window = (Stage) ((Node) ev.getSource()).getScene().getWindow();

        window.setScene(loginScene);
        window.show();


    }

    public void insertProduct(ActionEvent event){
        String pName = productNameText.getText();
        String category = categoryText.getText();

        try{
            if(!productNameText.getText().trim().isEmpty() && !categoryText.getText().trim().isEmpty()) {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                String query = "Insert into product_info(Product_Name,Category) values('" + pName + "','" + category + "')";


                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");

                productNameText.setText(null);
                categoryText.setText(null);
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }
        fillTable("SELECT * FROM product_info",productInfoTable);
    }

    public void fillTable(String statement,TableView table){
        table.getColumns().clear();
        Connection c ;

        data = FXCollections.observableArrayList();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");

            //sql string ifademiz.
            String SQL = statement;//tablomuzun adı bilgi. id ve adi alanları var.
            //ResultSet
            ResultSet rs = conn.createStatement().executeQuery(SQL);



            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                table.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            //ObservableList e verileri ekleyen döngü
            while(rs.next()){
                //Satırları yinele
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //sütunları yinele
                    row.add(rs.getString(i));
                }
                System.out.println("Satır eklendi "+row );
                data.add(row);
            }

            //Sonucu tabloya ekleme
            table.setItems(data);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hata oluştu");
        }
    }

    public void createInspection(ActionEvent event){

        String pid = patientIDText.getText();
        String pcomp = pCompText.getText();
        String idate = insdate.getValue().toString();
        String did = docIDText.getText();

        System.out.println(idate);
        try{
            if(!patientIDText.getText().trim().isEmpty() && !pCompText.getText().trim().isEmpty() && !idate.trim().isEmpty() && !docIDText.getText().trim().isEmpty()) {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                //String query = "Insert into inspection(P_ID,D_ID,Date,Clock,department) values('"+pid+"','"+did+"','"+idate+"','"+iclock+"','"+pcomp+"')";
                String query = "CALL insertInspection('" + pid + "','" + did + "','" + idate + "','" + pcomp + "')";
                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");


                //updating doctor availability with func.
                UpdateDoctor(did);

                pName.setText(null);
                pSurname.setText(null);
                pBirthDate.setText(null);
                pGender.setText(null);
                pAddress.setText(null);
                pPhone.setText(null);
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }

        patientIDText.clear();
        pCompText.clear();
        docIDText.clear();
        fillTable("SELECT * FROM inspection_without_id",inspectionTable);
        fillTable("SELECT * FROM insdetail_without_id",insDetailTable);
    }

    public void UpdateDoctor(String DoctorID){

        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");
            System.out.println("DB Connected");
            String query = "UPDATE doctor_availability SET Availability='NO' where D_ID = '"+DoctorID+"'";

            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);
            System.out.print("Updated");

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }

    }

    public void createReceiptDetail(ActionEvent event){


        String receiptCode = receiptCodeText.getText();
        String receiptDesc = receiptDescText.getText();
        int insID = Integer.parseInt(wanted_Column);
        System.out.println(insID+"asdasds");

        try{
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                //String query = "Insert into patients(P_Name,P_Surname,B_Date,Gender,Adress,Phone_Number) values('"+pname+"','"+psurname+"','"+pbirthdate+"','"+pgender+"','"+paddress+"','"+pphone+"')";
                //String query = "CALL updateInspectionDetail('" + insID + "','" + receiptCode + "','" + receiptDesc + "')";
                String query = "UPDATE inspections_detail SET Prescription_Code =  '"+receiptCode+"', Decision = '"+receiptDesc+"' WHERE I_ID = '"+insID+"' ";

                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");

                receiptCodeText.setText(generateReceiptCode());

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }


        receiptCodeText.clear();
        receiptDescText.clear();
        receiptCodeText.setText(generateReceiptCode());
        fillTable("SELECT * FROM insdetail_without_id",insDetailTable);
    }

    public void UpdateQuantity(ActionEvent event){

        String quantity = quantityText.getText();

        try{
            if(!quantityText.getText().trim().isEmpty()) {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                String query = "UPDATE product_stock SET Quantity='" + quantity + "' where Product_ID = '" + wanted_product + "'";
                String query1 = "DELETE FROM product_order where Product_ID='" + wanted_product + "'";

                Statement stmt = conn.createStatement();
                Statement stmt1 = conn.createStatement();

                stmt.executeUpdate(query);
                stmt1.execute(query1);
                System.out.print("Updated");
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }
        fillTable("SELECT * FROM product_order",productOrderTable);
        fillTable("SELECT * FROM product_stock",productStockTable);
    }

    @FXML
    public void selectFirst(MouseEvent event){
        Object selectedItems = insDetailTable.getSelectionModel().getSelectedItems();
        wanted_Column = selectedItems.toString().split(",")[0].substring(2);
        System.out.println(wanted_Column);
    }

    @FXML
    public void selectQuantity(MouseEvent event){
        Object selectedItems = productOrderTable.getSelectionModel().getSelectedItems();
        wanted_quantity = selectedItems.toString().split(",")[3].substring(1,4);
        wanted_product = selectedItems.toString().split(",")[1].substring(1);

        quantityText.setText(wanted_quantity);
        System.out.println(wanted_quantity);
        System.out.println(wanted_product);
    }




}
