package sample;

import com.mysql.cj.protocol.Message;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.swing.*;
import java.io.IOException;
import java.sql.*;
import java.util.prefs.Preferences;


public class Controller {
    public Button loginButton;
    public TextField usernameText;
    public TextField passwordText;

    private ObservableList data;

    public void login(ActionEvent event) throws IOException {
        String username = usernameText.getText();
        String password = passwordText.getText();

            System.out.print(username+password);

        Parent adminParent = FXMLLoader.load(getClass().getResource("managementScene.fxml"));
        Scene adminScene = new Scene(adminParent);

        Parent doctorParent = FXMLLoader.load(getClass().getResource("doctorScene.fxml"));
        Scene doctorScene = new Scene(doctorParent);

        Parent receptionistParent = FXMLLoader.load(getClass().getResource("receptionistScene.fxml"));
        Scene receptionistScene = new Scene(receptionistParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();


            try{
                if(!usernameText.getText().trim().isEmpty()  && !passwordText.getText().trim().isEmpty()) {
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                    System.out.println("DB Connected");



                    String query = "Select * from admin where Username = '" + username + "' and Password='" + password + "' ";
                    String query1 = "Select * from doctor_login where Username = '" + username + "' and D_Password='" + password + "' ";
                    String query2 = "Select * from employee where Username = '" + username + "' and E_Password='" + password + "' ";
                    Statement stmt = conn.createStatement();
                    Statement stmt1 = conn.createStatement();
                    Statement stmt2 = conn.createStatement();

                    ResultSet rs = stmt.executeQuery(query);
                    ResultSet rs1 = stmt1.executeQuery(query1);
                    ResultSet rs2 = stmt2.executeQuery(query2);


                    if (rs.next()) {
                        System.out.println("Succes!");
                        System.out.print(rs.getString(3));

                        String info = rs.getString(3);
                /*window.setScene(adminScene);
                window.show();*/

               /* switch(info) {
                    case "Admin":
                        window.setScene(adminScene);
                        window.show();
                        break;

                    case "Doctor":
                        window.setScene(doctorScene);
                        window.show();
                        break;
                }*/
                        window.setScene(adminScene);
                        window.show();


                    } else if (rs1.next()) {
                        System.out.println("Succes!");
                        System.out.print(rs1.getString(3));

                        String info = rs1.getString(3);
                /*window.setScene(adminScene);
                window.show();*/

               /* switch(info) {
                    case "Admin":
                        window.setScene(adminScene);
                        window.show();
                        break;

                    case "Doctor":
                        window.setScene(doctorScene);
                        window.show();
                        break;
                }*/
                        window.setScene(doctorScene);
                        window.show();
                    } else if (rs2.next()) {
                        System.out.println("Succes!");
                        System.out.print(rs2.getString(3));

                        String info = rs2.getString(3);
                /*window.setScene(adminScene);
                window.show();*/

               /* switch(info) {
                    case "Admin":
                        window.setScene(adminScene);
                        window.show();
                        break;

                    case "Doctor":
                        window.setScene(doctorScene);
                        window.show();
                        break;
                }*/
                        window.setScene(receptionistScene);
                        window.show();
                    } else {
                        wrongUser("Please enter correct information");
                    }
                }else{
                    wrongUser("Please enter required information");
                }

            }catch (Exception e){
                System.out.println("DB Failed");
                System.out.println(e.getMessage());
                wrongUser("Cannot connect to DB");

            }


    }

    public void wrongUser(String msg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Error occured");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

}
