package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class receptionistSceneController {
    //Patient
    public Tab patientTab;
    public TextField pName;
    public TextField pSurname;
    public TextField pBirthDate;
    public TextField pGender;
    public TextArea pAddress;
    public TextField pPhone;
    public TextField pID;
    public TableView tableview;
    private ObservableList data;

    //inspection
    public Tab inspectionTab;
    public TableView inspectionTable;
    public TextField patientIdText;
    public TextField doctorIdText;
    public DatePicker dateText;
    public TextField patientCompText;

    //Product
    public Tab productTab;

    public TableView productInfoTable;

    public TextField productNameText;
    public TextField categoryText;

    //Order
    public Tab orderTab;

    public TableView productOrderTable;
    public TableView productStockTable;

    public TextField quantityText;


    public String wanted_quantity;
    public String wanted_product;

    public void nullRequireInfo(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Error occured");
        alert.setHeaderText(null);
        alert.setContentText("Please enter required information");
        alert.showAndWait();
    }

    @FXML
    void patientTabSelected(Event event)throws IOException {

        if (patientTab.isSelected()) {
            System.out.println("Tab is Selected");
            fillTable("patients",tableview);

        }
    }

    @FXML
    void exitButton(ActionEvent ev)throws IOException{
        Parent loginParent = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene loginScene = new Scene(loginParent);

        Stage window = (Stage) ((Node) ev.getSource()).getScene().getWindow();

        window.setScene(loginScene);
        window.show();


    }

    public void insertPatient(ActionEvent event){

        String pname = pName.getText();
        String psurname = pSurname.getText();
        String pbirthdate = pBirthDate.getText();
        String pgender = pGender.getText();
        String paddress = pAddress.getText();
        String pphone = pPhone.getText();


        try{
            if(!pName.getText().trim().isEmpty() && !pSurname.getText().trim().isEmpty() && !pBirthDate.getText().trim().isEmpty() && !pGender.getText().trim().isEmpty() && !pAddress.getText().trim().isEmpty() && !pPhone.getText().trim().isEmpty() ) {

                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                //String query = "Insert into patients(P_Name,P_Surname,B_Date,Gender,Adress,Phone_Number) values('"+pname+"','"+psurname+"','"+pbirthdate+"','"+pgender+"','"+paddress+"','"+pphone+"')";
                String query = "CALL insertPatient('" + pname + "','" + psurname + "','" + pbirthdate + "','" + pgender + "','" + paddress + "','" + pphone + "')";

                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");

                pName.setText(null);
                pSurname.setText(null);
                pBirthDate.setText(null);
                pGender.setText(null);
                pAddress.setText(null);
                pPhone.setText(null);
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }
        fillTable("patients",tableview);
    }

    public void fillTable(String tableName,TableView table){
        table.getColumns().clear();
        Connection c ;

        data = FXCollections.observableArrayList();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");

            //sql string ifademiz.
            String SQL = "SELECT * from "+tableName+" ";//tablomuzun adı bilgi. id ve adi alanları var.
            //ResultSet
            ResultSet rs = conn.createStatement().executeQuery(SQL);



            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                table.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            //ObservableList e verileri ekleyen döngü
            while(rs.next()){
                //Satırları yinele
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //sütunları yinele
                    row.add(rs.getString(i));
                }
                System.out.println("Satır eklendi "+row );
                data.add(row);
            }

            //Sonucu tabloya ekleme
            table.setItems(data);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hata oluştu");
        }
    }

    public void searchPatient(ActionEvent event){
        tableview.getColumns().clear();
        String pid = pID.getText();


        data = FXCollections.observableArrayList();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");

            //sql string ifademiz.
            //String SQL = "SELECT * from patients where P_ID = '"+pid+"'";//tablomuzun adı bilgi. id ve adi alanları var.
            String SQL = "CALL searchPatient('"+pid+"')";


            //ResultSet
            ResultSet rs = conn.createStatement().executeQuery(SQL);



            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                tableview.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            //ObservableList e verileri ekleyen döngü
            while(rs.next()){
                //Satırları yinele
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //sütunları yinele
                    row.add(rs.getString(i));
                }
                System.out.println("Satır eklendi "+row );
                data.add(row);
            }

            //Sonucu tabloya ekleme
            tableview.setItems(data);
            pID.setText(null);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hata oluştu");
        }
    }

    public void clearPatientTable (ActionEvent event){
        fillTable("patients",tableview);
    }

    @FXML
    void insTabSelected(Event ev) {
        if (inspectionTab.isSelected()) {
            System.out.println("Tab is Selected");

            fillTable("inspection_without_id",inspectionTable);
        }
    }

    @FXML
    void productTabSelected(Event ev){
        if(productTab.isSelected()){
            System.out.println("Tab is selected");
            fillTable("product_info",productInfoTable);
        }
    }

    @FXML
    void orderTabSelected(Event ev){
        if(orderTab.isSelected()){
            System.out.println("Tab is selected");
            fillTable("product_order",productOrderTable);
            fillTable("product_stock",productStockTable);
        }
    }

    public void insertProduct(ActionEvent event){
        String pName = productNameText.getText();
        String category = categoryText.getText();

        try{
            if(!productNameText.getText().trim().isEmpty() && !categoryText.getText().trim().isEmpty()) {

                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                String query = "Insert into product_info(Product_Name,Category) values('" + pName + "','" + category + "')";


                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");

                productNameText.setText(null);
                categoryText.setText(null);
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }
        fillTable("product_info",productInfoTable);
    }

    public void UpdateQuantity(ActionEvent event){

        String quantity = quantityText.getText();
        int wproduct = Integer.parseInt(wanted_product);

        try{
            if(!quantityText.getText().trim().isEmpty()) {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                String query = "UPDATE product_stock SET Quantity='" + quantity + "' where Product_ID = '" + wproduct + "'";
                String query1 = "DELETE FROM product_order where Product_ID='" + wproduct + "'";

                Statement stmt = conn.createStatement();
                Statement stmt1 = conn.createStatement();

                stmt.executeUpdate(query);
                stmt1.execute(query1);
                System.out.print("Updated");
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }
        fillTable("product_order",productOrderTable);
        fillTable("product_stock",productStockTable);
    }

    @FXML
    public void selectQuantity(MouseEvent event){
        Object selectedItems = productOrderTable.getSelectionModel().getSelectedItems();
        wanted_quantity = selectedItems.toString().split(",")[3].substring(1,4);
        wanted_product = selectedItems.toString().split(",")[1].substring(1);

        quantityText.setText(wanted_quantity);
        System.out.println(wanted_quantity);
        System.out.println(wanted_product);
    }

    public void createInspection(ActionEvent event){

        String pid = patientIdText.getText();
        String pcomp = patientCompText.getText();
        String idate = dateText.getValue().toString();
        String did = doctorIdText.getText();

        System.out.println(idate);
        try{
            if(!patientIdText.getText().trim().isEmpty() && !patientCompText.getText().trim().isEmpty() && dateText.getValue() != null && !doctorIdText.getText().trim().isEmpty()) {

                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey", "root", "");
                System.out.println("DB Connected");
                //String query = "Insert into inspection(P_ID,D_ID,Date,Clock,department) values('"+pid+"','"+did+"','"+idate+"','"+iclock+"','"+pcomp+"')";
                String query = "CALL insertInspection('" + pid + "','" + did + "','" + idate + "','" + pcomp + "')";
                Statement stmt = conn.createStatement();
                stmt.executeUpdate(query);
                System.out.print("inserted");


                //updating doctor availability with func.
                UpdateDoctor(did);

                pName.setText(null);
                pSurname.setText(null);
                pBirthDate.setText(null);
                pGender.setText(null);
                pAddress.setText(null);
                pPhone.setText(null);
            }else{
                nullRequireInfo();
            }

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());


        }

        patientIdText.clear();
        patientCompText.clear();
        doctorIdText.clear();
        fillTable("inspections",inspectionTable);
    }

    public void UpdateDoctor(String DoctorID){

        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/hastane_proje?useUnicode=true&useLegacyDatetimeCode=false&serverTimezone=Turkey","root","");
            System.out.println("DB Connected");
            String query = "UPDATE doctor_availability SET Availability='NO' where D_ID = '"+DoctorID+"'";

            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);
            System.out.print("Updated");

        }catch (Exception e){
            System.out.println("DB Failed");
            System.out.println(e.getMessage());

        }

    }


}
